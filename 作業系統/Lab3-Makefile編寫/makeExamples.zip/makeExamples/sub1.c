/* sub1.c */
#include <stdio.h>
#include "sub1.h"

void fun1() {
	printf("1111\n");
}
