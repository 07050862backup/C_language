/* main.c */
#include <stdio.h>
#include "common.h"
#include "sub0.h"
#include "sub1.h"

int main()
{
	printf("main\n");    
	fun0();
	fun1();
	return 0;
}
