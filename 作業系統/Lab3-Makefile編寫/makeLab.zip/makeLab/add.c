/* add.c */
#include <stdio.h>
#include "common.h"
#include "add.h"

int x = 1;
void add() {
	x = x + COUNT;
	printf("x=%d\n", x);
}
