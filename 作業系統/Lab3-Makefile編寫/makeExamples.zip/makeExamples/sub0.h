void fun0(void); 

