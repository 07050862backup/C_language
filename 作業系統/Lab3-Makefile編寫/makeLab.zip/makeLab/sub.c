/* sub.c */
#include <stdio.h>
#include "common.h"
#include "sub.h"

int y = 10;
void sub() {
	y = y - COUNT;
	printf("y=%d\n", y);
}
