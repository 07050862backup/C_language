/* sub0.c */
#include <stdio.h>
#include "sub0.h"

void fun0() {
	printf("0000\n");
}
