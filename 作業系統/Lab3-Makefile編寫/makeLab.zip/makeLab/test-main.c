/* test-main.c */
#include <stdio.h>
#include "add.h"
#include "sub.h"

int main()
{
	add();
	add();
	sub();
	sub();
	return 0;
}
